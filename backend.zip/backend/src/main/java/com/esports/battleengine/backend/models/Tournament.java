package com.esports.battleengine.backend.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.*;

import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "tournaments")
public class Tournament {

    @Id
    private String id;

    @NotBlank(message = "Tournament name is required")
    private String name;

    @NotBlank(message = "Game is required")
    private String gameName;

    @NotNull(message = "Game type is required")
    private GameType gameType;

    private String organizerId;

    private String format;

    @Min(value = 2, message = "Minimum 2 teams required")
    private Integer maxTeams;

    private List<String> teamIds;

    @Future(message = "Start date must be in the future")
    private LocalDateTime startDate;

    private String status;

    private Boolean locked;

    // UI and Display fields
    private String description;
    private String prizePool;
    private String region;
    private String gameIcon; // e.g. "🎯", "🔫"
    private String bannerUrl;
}
