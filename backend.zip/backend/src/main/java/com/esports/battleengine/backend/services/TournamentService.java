package com.esports.battleengine.backend.services;

import com.esports.battleengine.backend.engine.EngineFactory;
import com.esports.battleengine.backend.engine.TournamentEngine;
import com.esports.battleengine.backend.exceptions.ApiException;
import com.esports.battleengine.backend.models.Match;
import com.esports.battleengine.backend.models.MatchStatus;
import com.esports.battleengine.backend.models.Tournament;
import com.esports.battleengine.backend.repositories.MatchRepository;
import com.esports.battleengine.backend.repositories.TournamentRepository;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Service
public class TournamentService {

    private final TournamentRepository repository;
    private final MatchRepository matchRepository;
    private final EngineFactory engineFactory;

    public TournamentService(TournamentRepository repository, MatchRepository matchRepository, EngineFactory engineFactory) {
        this.repository = repository;
        this.matchRepository = matchRepository;
        this.engineFactory = engineFactory;
    }

    public Tournament create(Tournament tournament) {
        tournament.setStatus("UPCOMING");
        tournament.setLocked(Boolean.FALSE);
        if (tournament.getTeamIds() == null) {
            tournament.setTeamIds(new ArrayList<>());
        }
        return repository.save(tournament);
    }

    public List<Tournament> getAll() {
        return repository.findAll();
    }

    public Tournament getById(String id) {
        return repository.findById(id).orElse(null);
    }

    public Tournament save(Tournament tournament) {
        return repository.save(tournament);
    }

    /**
     * Lock tournament registration and set status to LIVE.
     * Also auto-generates Round 1 bracket matches if there are registered teams.
     */
    public Tournament startTournament(String tournamentId) {
        Tournament tournament = repository.findById(tournamentId)
                .orElseThrow(() -> new ApiException("Tournament not found"));

        if (Boolean.TRUE.equals(tournament.getLocked())) {
            throw new ApiException("Tournament is already started/locked.");
        }

        if (tournament.getTeamIds() == null || tournament.getTeamIds().size() < 2) {
            throw new ApiException("At least 2 teams are required to start the tournament.");
        }

        if ("COMPLETED".equalsIgnoreCase(tournament.getStatus())) {
            throw new ApiException("Tournament is already completed.");
        }

        tournament.setLocked(true);
        tournament.setStatus("LIVE");
        Tournament saved = repository.save(tournament);

        // Generate matches using Engine based on GameType
        if (saved.getGameType() == null) {
            throw new ApiException("GameType is not set for this tournament.");
        }

        TournamentEngine engine = engineFactory.getEngine(saved.getGameType());
        engine.generateMatches(saved);

        return saved;
    }

    /**
     * Legacy lock endpoint - also starts the tournament for backward compat.
     */
    public Tournament lockTournament(String tournamentId) {
        return startTournament(tournamentId);
    }

    /**
     * Add a team to the tournament (join tournament).
     */
    public Tournament joinTournament(String tournamentId, String teamId) {
        Tournament tournament = repository.findById(tournamentId)
                .orElseThrow(() -> new ApiException("Tournament not found"));

        if (Boolean.TRUE.equals(tournament.getLocked())) {
            throw new ApiException("Tournament registration is closed.");
        }

        if ("COMPLETED".equalsIgnoreCase(tournament.getStatus())) {
            throw new ApiException("Cannot join a completed tournament.");
        }

        List<String> teams = tournament.getTeamIds();
        if (teams == null) teams = new ArrayList<>();

        if (teams.contains(teamId)) {
            throw new ApiException("Team is already registered in this tournament.");
        }

        if (tournament.getMaxTeams() != null && teams.size() >= tournament.getMaxTeams()) {
            throw new ApiException("Tournament is full.");
        }

        teams.add(teamId);
        tournament.setTeamIds(teams);
        return repository.save(tournament);
    }

    public Tournament completeTournament(String tournamentId) {
        Tournament tournament = repository.findById(tournamentId)
                .orElseThrow(() -> new ApiException("Tournament not found"));

        if (!Boolean.TRUE.equals(tournament.getLocked())) {
            throw new ApiException("Tournament has not started yet.");
        }

        tournament.setStatus("COMPLETED");
        return repository.save(tournament);
    }
}
