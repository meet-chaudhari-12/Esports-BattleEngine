package com.esports.battleengine.backend.engine;

import com.esports.battleengine.backend.exceptions.ApiException;
import com.esports.battleengine.backend.models.GameType;
import org.springframework.stereotype.Component;

import java.util.Map;

@Component
public class ScoringEngineFactory {

    private final Map<String, ScoringEngine> engines;

    public ScoringEngineFactory(Map<String, ScoringEngine> engines) {
        this.engines = engines;
    }

    public ScoringEngine getEngine(String gameName, GameType gameType) {
        ScoringEngine engine = engines.get(gameName);
        
        if (engine == null) {
            engine = engines.get("DEFAULT");
        }

        if (engine == null) {
            throw new ApiException("No scoring engine available.");
        }
        
        return engine;
    }
}
