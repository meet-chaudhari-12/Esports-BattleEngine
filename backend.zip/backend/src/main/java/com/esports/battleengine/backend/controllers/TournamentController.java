package com.esports.battleengine.backend.controllers;

import com.esports.battleengine.backend.models.Tournament;
import com.esports.battleengine.backend.services.TournamentService;
import org.springframework.http.ResponseEntity;
import jakarta.validation.Valid;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/tournaments")
public class TournamentController {

    private final TournamentService service;

    public TournamentController(TournamentService service) {
        this.service = service;
    }

    @PostMapping
    @PreAuthorize("hasRole('ORGANIZER') or hasRole('ADMIN')")
    public Tournament create(@Valid @RequestBody Tournament tournament) {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        if (principal instanceof com.esports.battleengine.backend.security.services.UserDetailsImpl) {
            String userId = ((com.esports.battleengine.backend.security.services.UserDetailsImpl) principal).getId();
            tournament.setOrganizerId(userId);
        }
        System.out.println("🔥 CREATE TOURNAMENT - Organizer: " + tournament.getOrganizerId() + " Game: " + tournament.getGameName());
        return service.create(tournament);
    }

    @GetMapping
    public List<Tournament> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public Tournament getById(@PathVariable String id) {
        return service.getById(id);
    }

    /**
     * Start tournament: locks registration, sets status LIVE, auto-generates bracket matches.
     */
    @PostMapping("/{id}/start")
    @PreAuthorize("hasRole('ORGANIZER') or hasRole('ADMIN')")
    public ResponseEntity<Tournament> startTournament(@PathVariable String id) {
        Tournament t = service.startTournament(id);
        return ResponseEntity.ok(t);
    }

    /**
     * Legacy lock endpoint - maps to startTournament for backwards compat.
     */
    @PostMapping("/{id}/lock")
    @PreAuthorize("hasRole('ORGANIZER') or hasRole('ADMIN')")
    public ResponseEntity<Tournament> lockTournament(@PathVariable String id) {
        Tournament t = service.lockTournament(id);
        return ResponseEntity.ok(t);
    }

    /**
     * Join tournament: adds a team to the tournament's teamIds list.
     * Body: { "teamId": "<team_id>" }
     */
    @PostMapping("/{id}/join")
    public ResponseEntity<Tournament> joinTournament(
            @PathVariable String id,
            @RequestBody Map<String, String> body
    ) {
        String teamId = body.get("teamId");
        if (teamId == null || teamId.isBlank()) {
            return ResponseEntity.badRequest().build();
        }
        Tournament t = service.joinTournament(id, teamId);
        return ResponseEntity.ok(t);
    }
}
