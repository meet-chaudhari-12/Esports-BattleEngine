package com.esports.battleengine.backend.controllers;

import com.esports.battleengine.backend.dto.MatchResultResponse;
import com.esports.battleengine.backend.models.Match;
import com.esports.battleengine.backend.services.MatchService;
import org.springframework.http.ResponseEntity;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/matches")
public class MatchController {

    private final MatchService service;

    public MatchController(MatchService service) {
        this.service = service;
    }

    /** Schedule a new match */
    @PostMapping("/schedule")
    public ResponseEntity<Match> schedule(@Valid @RequestBody Match match) {
        return ResponseEntity.ok(service.scheduleMatch(match));
    }

    /**
     * Submit raw result data for a match.
     * The scoring engine calculates finalScore and determines winner.
     */
    @PostMapping("/{id}/result")
    public ResponseEntity<Match> submitResult(
            @PathVariable String id,
            @RequestBody Map<String, Object> rawData
    ) {
        return ResponseEntity.ok(service.submitResult(id, rawData));
    }

    /**
     * Get the rich match result with per-team rankings and scores.
     * Used by the MatchResult frontend page after scores are submitted.
     */
    @GetMapping("/{id}/result")
    public ResponseEntity<MatchResultResponse> getMatchResult(@PathVariable String id) {
        return ResponseEntity.ok(service.getMatchResult(id));
    }

    /** Get all matches for a tournament */
    @GetMapping("/tournament/{tournamentId}")
    public ResponseEntity<List<Match>> getByTournament(@PathVariable String tournamentId) {
        return ResponseEntity.ok(service.getMatchesByTournament(tournamentId));
    }

    /** Get a single match by ID */
    @GetMapping("/{id}")
    public ResponseEntity<Match> getById(@PathVariable String id) {
        return ResponseEntity.ok(service.getMatchById(id));
    }

    /** Get all matches (for dashboard stats) */
    @GetMapping
    public ResponseEntity<List<Match>> getAll() {
        return ResponseEntity.ok(service.getAllMatches());
    }
}
