package com.esports.battleengine.backend.services;

import com.esports.battleengine.backend.exceptions.ApiException;
import com.esports.battleengine.backend.models.GameRule;
import com.esports.battleengine.backend.models.GameType;
import com.esports.battleengine.backend.repositories.GameRuleRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GameRuleService {

    private final GameRuleRepository gameRuleRepository;

    public GameRuleService(GameRuleRepository gameRuleRepository) {
        this.gameRuleRepository = gameRuleRepository;
    }

    public GameRule createRule(GameRule rule) {
        return gameRuleRepository.save(rule);
    }

    public GameRule getRuleByGameName(String gameName) {
        if (gameName == null || gameName.isBlank()) {
            return getDefaultRule("DEFAULT");
        }
        return gameRuleRepository.findByGameNameIgnoreCase(gameName)
                .orElseGet(() -> getDefaultRule(gameName));
    }

    private GameRule getDefaultRule(String gameName) {
        GameRule defaultRule = new GameRule();
        defaultRule.setGameName(gameName);
        defaultRule.setScoringType(com.esports.battleengine.backend.models.ScoringType.POINTS);
        defaultRule.setRuleConfig(java.util.Collections.emptyMap());
        defaultRule.setGameType(GameType.ROUND_BASED);
        return defaultRule;
    }

    public List<GameRule> getRulesByType(GameType gameType) {
        return gameRuleRepository.findByGameType(gameType);
    }

    public List<GameRule> getAllRules() {
        return gameRuleRepository.findAll();
    }
}
