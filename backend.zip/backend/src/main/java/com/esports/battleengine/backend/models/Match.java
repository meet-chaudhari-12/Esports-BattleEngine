package com.esports.battleengine.backend.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.*;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "matches")
public class Match {

    @Id
    private String id;

    @NotBlank(message = "Tournament ID is required")
    private String tournamentId;

    private String gameName;
    private GameType gameType;

    // Participating Teams (2 for most games)
    @NotNull(message = "Team list cannot be null")
    @Size(min = 1, message = "At least one team is required")
    private List<String> teamIds;          
    
    private Map<String, Object> rawResult; 
    private Map<String, Integer> finalScore; 
    
    private LocalDateTime scheduledAt;
    
    @Builder.Default
    private MatchStatus status = MatchStatus.SCHEDULED; 

    // Bracket Logic
    @Min(value = 1, message = "Round must be at least 1")
    private Integer round; // 1 = Ro64, 2 = Ro32, ... (or 1 is final? Usually 1 is first round)
    private Integer bracketIndex; // Horizontal position in the round (0, 1, 2...)
    private String nextMatchId; // ID of the match the winner advances to
    
    // For specific progression logic
    private String winnerTeamId;

    private LocalDateTime completedAt;
}
