package com.esports.battleengine.backend.services;

import com.esports.battleengine.backend.dto.MatchResultResponse;
import com.esports.battleengine.backend.engine.EngineFactory;
import com.esports.battleengine.backend.engine.TournamentEngine;
import com.esports.battleengine.backend.exceptions.ApiException;
import com.esports.battleengine.backend.models.Match;
import com.esports.battleengine.backend.models.MatchStatus;
import com.esports.battleengine.backend.models.Team;
import com.esports.battleengine.backend.models.Tournament;
import com.esports.battleengine.backend.repositories.MatchRepository;
import com.esports.battleengine.backend.repositories.TeamRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class MatchService {

    private final MatchRepository matchRepository;
    private final GameRuleService gameRuleService;
    private final EngineFactory engineFactory;
    private final TournamentService tournamentService;
    private final TeamRepository teamRepository;
    private final LeaderboardService leaderboardService;

    public MatchService(
            MatchRepository matchRepository,
            GameRuleService gameRuleService,
            EngineFactory engineFactory,
            TournamentService tournamentService,
            TeamRepository teamRepository,
            LeaderboardService leaderboardService
    ) {
        this.matchRepository = matchRepository;
        this.gameRuleService = gameRuleService;
        this.engineFactory = engineFactory;
        this.tournamentService = tournamentService;
        this.teamRepository = teamRepository;
        this.leaderboardService = leaderboardService;
    }

    /* ─────────────────────────────────────────── schedule ── */
    public Match scheduleMatch(Match match) {
        Tournament tournament = tournamentService.getById(match.getTournamentId());
        if (tournament == null) {
            throw new ApiException("Tournament not found");
        }

        // Auto-inherit game from tournament if not set
        if (match.getGameName() == null || match.getGameName().isBlank()) {
            match.setGameName(tournament.getGameName());
        }

        if (match.getGameType() == null) {
            match.setGameType(tournament.getGameType());
        }

        if (match.getGameName() == null || match.getGameName().isBlank()) {
            throw new ApiException("Game must be specified for the match or tournament.");
        }

        match.setStatus(MatchStatus.SCHEDULED);
        if (match.getScheduledAt() == null) {
            match.setScheduledAt(LocalDateTime.now());
        }
        return matchRepository.save(match);
    }

    /* ─────────────────────────────────────── getters ── */
// ... (lines 70-81 unchanged)
    public Match getMatchById(String matchId) {
        return matchRepository.findById(matchId)
                .orElseThrow(() -> new ApiException("Match not found: " + matchId));
    }

    /* ─────────────────────────────────── submit result ── */
    public Match submitResult(String matchId, Map<String, Object> rawData) {
        Match match = matchRepository.findById(matchId)
                .orElseThrow(() -> new ApiException("Match not found"));

        if (match.getStatus() == MatchStatus.COMPLETED) {
            throw new ApiException("Match is already completed.");
        }

        Tournament tournament = tournamentService.getById(match.getTournamentId());
        // Auto-start tournament if not yet locked (match was manually scheduled)
        if (tournament != null && !Boolean.TRUE.equals(tournament.getLocked())) {
            tournament.setLocked(true);
            if (!"LIVE".equalsIgnoreCase(tournament.getStatus()) && !"COMPLETED".equalsIgnoreCase(tournament.getStatus())) {
                tournament.setStatus("LIVE");
            }
            tournamentService.save(tournament);
        }

        if (tournament != null && "COMPLETED".equalsIgnoreCase(tournament.getStatus())) {
            throw new ApiException("Tournament is already completed.");
        }

        TournamentEngine engine = engineFactory.getEngine(match.getGameType());
        engine.processMatchResult(match, rawData);

        // Fetch the updated match (including finalScore and winner)
        Match savedMatch = matchRepository.findById(matchId).orElse(match);
        leaderboardService.recalculate(match.getTournamentId());
        return savedMatch;
    }

    /* ─────────────────────────────── match result response ── */
    /**
     * Returns a rich MatchResultResponse for a completed match,
     * including a per-team ranked leaderboard and winner details.
     */
    public MatchResultResponse getMatchResult(String matchId) {
        Match match = matchRepository.findById(matchId)
                .orElseThrow(() -> new ApiException("Match not found: " + matchId));

        if (match.getStatus() != MatchStatus.COMPLETED) {
            throw new ApiException("Match is not yet completed.");
        }

        // Build team name cache
        Map<String, String> nameCache = new HashMap<>();
        if (match.getTeamIds() != null) {
            for (String tid : match.getTeamIds()) {
                teamRepository.findById(tid)
                        .map(Team::getName)
                        .ifPresent(name -> nameCache.put(tid, name));
            }
        }

        // Build ranked match leaderboard from finalScore
        Map<String, Integer> scoreMap = match.getFinalScore() != null
                ? match.getFinalScore()
                : Collections.emptyMap();

        List<MatchResultResponse.MatchTeamScore> ranked = scoreMap.entrySet().stream()
                .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                .map(e -> MatchResultResponse.MatchTeamScore.builder()
                        .teamId(e.getKey())
                        .teamName(nameCache.getOrDefault(e.getKey(), e.getKey()))
                        .score(e.getValue())
                        .isWinner(e.getKey().equals(match.getWinnerTeamId()))
                        .build())
                .collect(Collectors.toList());

        // Assign ranks
        for (int i = 0; i < ranked.size(); i++) {
            ranked.get(i).setRank(i + 1);
        }

        // If score map is empty but teams exist, still show them
        if (ranked.isEmpty() && match.getTeamIds() != null) {
            for (int i = 0; i < match.getTeamIds().size(); i++) {
                String tid = match.getTeamIds().get(i);
                ranked.add(MatchResultResponse.MatchTeamScore.builder()
                        .rank(i + 1)
                        .teamId(tid)
                        .teamName(nameCache.getOrDefault(tid, tid))
                        .score(0)
                        .isWinner(tid.equals(match.getWinnerTeamId()))
                        .build());
            }
        }

        String winnerName = match.getWinnerTeamId() != null
                ? nameCache.getOrDefault(match.getWinnerTeamId(), match.getWinnerTeamId())
                : null;

        return MatchResultResponse.builder()
                .matchId(match.getId())
                .tournamentId(match.getTournamentId())
                .gameName(match.getGameName())
                .round(match.getRound())
                .completedAt(match.getCompletedAt())
                .winnerTeamId(match.getWinnerTeamId())
                .winnerTeamName(winnerName)
                .matchLeaderboard(ranked)
                .build();
    }

    public List<Match> getMatchesByTournament(String tournamentId) {
        return matchRepository.findByTournamentId(tournamentId);
    }

    public List<Match> getAllMatches() {
        return matchRepository.findAll();
    }
}
