package com.esports.battleengine.backend.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import jakarta.validation.constraints.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "players")
public class Player {

    @Id
    private String id;

    @NotBlank(message = "Player name is required")
    @Size(min = 2, max = 50, message = "Player name must be between 2 and 50 characters")
    private String name;

    @NotBlank(message = "In-game name is required")
    @Size(min = 2, max = 30, message = "IGN must be between 2 and 30 characters")
    private String inGameName;

    private String role;
    private String country;

    @Min(value = 10, message = "Minimum age is 10")
    @Max(value = 60, message = "Age must be realistic")
    private Integer age;
    private String teamId;
}
