package com.esports.battleengine.backend.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class LeaderboardEntry {

    private String teamId;
    private String teamName;
    private Integer totalScore;
    private Integer matchesPlayed;
    private Integer wins;
    private Integer rank;
}
