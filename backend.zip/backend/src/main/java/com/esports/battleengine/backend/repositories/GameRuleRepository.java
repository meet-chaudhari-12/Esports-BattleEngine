package com.esports.battleengine.backend.repositories;

import com.esports.battleengine.backend.models.GameRule;
import com.esports.battleengine.backend.models.GameType;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface GameRuleRepository extends MongoRepository<GameRule, String> {

    Optional<GameRule> findByGameNameIgnoreCase(String gameName);

    List<GameRule> findByGameType(GameType gameType);
}
