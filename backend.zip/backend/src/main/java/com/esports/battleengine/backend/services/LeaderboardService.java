package com.esports.battleengine.backend.services;

import com.esports.battleengine.backend.dto.LeaderboardEntry;
import com.esports.battleengine.backend.models.Match;
import com.esports.battleengine.backend.models.MatchStatus;
import com.esports.battleengine.backend.models.Team;
import com.esports.battleengine.backend.repositories.MatchRepository;
import com.esports.battleengine.backend.repositories.TeamRepository;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class LeaderboardService {

    private final MatchRepository matchRepository;
    private final TeamRepository teamRepository;

    public LeaderboardService(MatchRepository matchRepository, TeamRepository teamRepository) {
        this.matchRepository = matchRepository;
        this.teamRepository = teamRepository;
    }

    public List<LeaderboardEntry> getLeaderboard(String tournamentId) {

        List<Match> completedMatches = matchRepository.findByTournamentIdAndStatus(
                tournamentId, MatchStatus.COMPLETED.name()
        );

        // teamId -> stats
        Map<String, Integer> scoreMap = new HashMap<>();
        Map<String, Integer> winsMap = new HashMap<>();
        Map<String, Integer> playedMap = new HashMap<>();

        for (Match match : completedMatches) {
            List<String> teamIds = match.getTeamIds();
            if (teamIds == null) continue;

            // Track matches played for each team
            for (String tid : teamIds) {
                playedMap.merge(tid, 1, Integer::sum);
            }

            // Track scores
            Map<String, Integer> matchScore = match.getFinalScore();
            if (matchScore != null) {
                for (Map.Entry<String, Integer> entry : matchScore.entrySet()) {
                    scoreMap.merge(entry.getKey(), entry.getValue(), Integer::sum);
                }
            }

            // Track wins
            if (match.getWinnerTeamId() != null) {
                winsMap.merge(match.getWinnerTeamId(), 1, Integer::sum);
            }
        }

        // Collect all unique team IDs from all three maps
        Set<String> allTeamIds = new HashSet<>();
        allTeamIds.addAll(scoreMap.keySet());
        allTeamIds.addAll(playedMap.keySet());

        // Build team name cache
        Map<String, String> teamNameCache = new HashMap<>();
        for (String tid : allTeamIds) {
            teamRepository.findById(tid).map(Team::getName).ifPresent(name -> teamNameCache.put(tid, name));
        }

        // Build leaderboard entries
        List<LeaderboardEntry> leaderboard = new ArrayList<>();
        for (String tid : allTeamIds) {
            int score = scoreMap.getOrDefault(tid, 0);
            int wins = winsMap.getOrDefault(tid, 0);
            int played = playedMap.getOrDefault(tid, 0);
            String teamName = teamNameCache.getOrDefault(tid, tid); // fallback to id
            leaderboard.add(new LeaderboardEntry(tid, teamName, score, played, wins, 0));
        }

        // Sort by score descending, then wins descending
        leaderboard.sort((a, b) -> {
            if (!b.getTotalScore().equals(a.getTotalScore())) return b.getTotalScore() - a.getTotalScore();
            return b.getWins() - a.getWins();
        });

        // Assign ranks
        for (int i = 0; i < leaderboard.size(); i++) {
            leaderboard.get(i).setRank(i + 1);
        }

        return leaderboard;
    }

    public void recalculate(String tournamentId) {
        // This method can be used to trigger cache updates or complex recalculations
        // For now, it's a placeholder as the leaderboard is calculated on the fly
        getLeaderboard(tournamentId);
    }
}
