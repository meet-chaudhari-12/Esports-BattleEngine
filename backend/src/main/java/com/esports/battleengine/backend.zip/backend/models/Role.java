package com.esports.battleengine.backend.models;

public enum Role {
    USER,
    ADMIN,
    ORGANIZER
}
