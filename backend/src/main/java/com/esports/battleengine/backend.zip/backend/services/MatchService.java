package com.esports.battleengine.backend.services;

import com.esports.battleengine.backend.engine.ScoringEngine;
import com.esports.battleengine.backend.engine.ScoringEngineFactory;
import com.esports.battleengine.backend.exceptions.ApiException;
import com.esports.battleengine.backend.models.GameRule;
import com.esports.battleengine.backend.models.Match;
import com.esports.battleengine.backend.models.MatchStatus;
import com.esports.battleengine.backend.models.Tournament;
import com.esports.battleengine.backend.repositories.MatchRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional; // Added import

@Service
public class MatchService {

    private final MatchRepository matchRepository;
    private final GameRuleService gameRuleService;
    private final ScoringEngineFactory scoringEngineFactory;
    private final TournamentService tournamentService;

    public MatchService(
            MatchRepository matchRepository,
            GameRuleService gameRuleService,
            ScoringEngineFactory scoringEngineFactory, TournamentService tournamentService
    ) {
        this.matchRepository = matchRepository;
        this.gameRuleService = gameRuleService;
        this.scoringEngineFactory = scoringEngineFactory;
        this.tournamentService = tournamentService;
    }

    public Match scheduleMatch(Match match) {
        Tournament tournament = tournamentService.getById(match.getTournamentId());
        if (tournament == null) {
            throw new ApiException("Tournament not found");
        }
        if (Boolean.TRUE.equals(tournament.getLocked())) {
            throw new ApiException("Tournament is locked. Cannot schedule matches.");
        }

        if (match.getGame() == null) {
            throw new ApiException("Game must be specified for match");
        }
        
        GameRule rule = gameRuleService.getRuleByGame(match.getGame());
        
        // Validation skipped for brevity if manual scheduling
        
        match.setStatus(MatchStatus.SCHEDULED);
        match.setScheduledAt(LocalDateTime.now());
        return matchRepository.save(match);
    }

    public List<Match> getMatchesByTournament(String tournamentId) {
        return matchRepository.findByTournamentId(tournamentId);
    }

    public Match submitResult(String matchId, Map<String, Object> rawData) {
        Match match = matchRepository.findById(matchId)
                .orElseThrow(() -> new ApiException("Match not found"));

        if (match.getStatus() == MatchStatus.COMPLETED) {
             throw new ApiException("Match is already completed.");
        }

        GameRule rule = gameRuleService.getRuleByGame(match.getGame());
        ScoringEngine engine = scoringEngineFactory.getEngine(rule.getGameName());

        Map<String, Integer> score = engine.calculateScore(rawData, rule);

        match.setRawResult(rawData);
        match.setFinalScore(score);
        match.setStatus(MatchStatus.COMPLETED);

        // Determine Winner (Simple highest score logic)
        String winnerId = null;
        int maxScore = -1;
        for (Map.Entry<String, Integer> entry : score.entrySet()) {
            if (entry.getValue() > maxScore) {
                maxScore = entry.getValue();
                winnerId = entry.getKey();
            }
        }
        
        if (winnerId != null) {
            match.setWinnerTeamId(winnerId);
            propagateWinner(match, winnerId);
        }

        return matchRepository.save(match);
    }

    private void propagateWinner(Match completedMatch, String winnerTeamId) {
        if (completedMatch.getNextMatchId() == null) return;

        Optional<Match> nextMatchOpt = matchRepository.findById(completedMatch.getNextMatchId());
        if (nextMatchOpt.isPresent()) {
            Match nextMatch = nextMatchOpt.get();
            if (nextMatch.getTeamIds() == null) {
                nextMatch.setTeamIds(new ArrayList<>());
            }
            if (!nextMatch.getTeamIds().contains(winnerTeamId)) {
                nextMatch.getTeamIds().add(winnerTeamId);
                matchRepository.save(nextMatch);
            }
        }
    }
}
