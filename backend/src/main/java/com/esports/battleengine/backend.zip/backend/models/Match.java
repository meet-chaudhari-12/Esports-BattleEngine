package com.esports.battleengine.backend.models;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
@Document(collection = "matches")
public class Match {

    @Id
    private String id;
    private String tournamentId;
    private String game;                  
    
    // Participating Teams (2 for most games)
    private List<String> teamIds;          
    
    private Map<String, Object> rawResult; 
    private Map<String, Integer> finalScore; 
    
    private LocalDateTime scheduledAt;
    
    @Builder.Default
    private MatchStatus status = MatchStatus.SCHEDULED; 

    // Bracket Logic
    private Integer round; // 1 = Ro64, 2 = Ro32, ... (or 1 is final? Usually 1 is first round)
    private Integer bracketIndex; // Horizontal position in the round (0, 1, 2...)
    private String nextMatchId; // ID of the match the winner advances to
    
    // For specific progression logic
    private String winnerTeamId;
}
