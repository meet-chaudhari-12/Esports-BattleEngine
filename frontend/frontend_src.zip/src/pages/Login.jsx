import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../auth/AuthContext";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { login } = useAuth();

  const handleLogin = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      // Store credentials so the interceptor can attach Basic Auth
      sessionStorage.setItem("username", username);
      sessionStorage.setItem("password", password);
      
      // Verify credentials with a real backend call
      await api.get("/tournaments");

      // Update auth context
      login(username);

      navigate("/dashboard");
    } catch (err) {
      console.error("Login error:", err);

      // Network / connectivity issues
      if (err.code === "ERR_NETWORK" || err.message?.includes("Network Error")) {
        setError(
          "Cannot connect to server. Make sure the backend is running on http://localhost:8080"
        );
      }
      // Invalid credentials
      else if (err.response?.status === 401) {
        setError("Invalid username or password. Please try again.");
      }
      // Permission denied
      else if (err.response?.status === 403) {
        setError(err.normalizedMessage || "You do not have permission to sign in with these credentials.");
      }
      // Bad request – surface backend message if provided
      else if (err.response?.status === 400) {
        setError(err.normalizedMessage || "Invalid request. Please check your input and try again.");
      }
      // Other server errors
      else {
        setError(
          err.normalizedMessage ||
            `Server error: ${err.response?.status || "Unknown error"}. Please try again.`
        );
      }

      // Clear invalid credentials so ProtectedRoute doesn't treat them as logged in
      sessionStorage.removeItem("username");
      sessionStorage.removeItem("password");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px"
      }}
    >
      <div className="card" style={{ maxWidth: "400px", width: "100%" }}>
        <div className="text-center mb-3">
          <h1 style={{ color: "var(--primary)", marginBottom: "0.5rem" }}>
            Esports BattleEngine
          </h1>
          <p style={{ color: "var(--text-light)" }}>Sign in to your account</p>
        </div>

        {error && <div className="error">{error}</div>}

        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label className="form-label">Username</label>
            <input
              type="text"
              className="form-input"
              placeholder="Enter username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-input"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            style={{ width: "100%" }}
            disabled={loading}
          >
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <div className="text-center mt-2">
          <p style={{ color: "var(--text-light)" }}>
            Don't have an account?{" "}
            <Link to="/register" style={{ color: "var(--primary)" }}>
              Register here
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;
