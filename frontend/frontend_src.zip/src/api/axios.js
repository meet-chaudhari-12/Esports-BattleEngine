import axios from "axios";

const api = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "http://localhost:8080/api",
  headers: {
    "Content-Type": "application/json"
  }
});

// Attach HTTP Basic Auth using credentials stored in sessionStorage
api.interceptors.request.use(
  (config) => {
    const username = sessionStorage.getItem("username");
    const password = sessionStorage.getItem("password");

    if (username && password) {
      const token = btoa(`${username}:${password}`);
      config.headers.Authorization = `Basic ${token}`;
    }

    return config;
  },
  (error) => Promise.reject(error)
);

// Centralized error handling and auth enforcement
api.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error?.response?.status;

    // Normalize backend business messages (e.g., "Tournament is locked")
    if (error?.response?.data?.message) {
      error.normalizedMessage = error.response.data.message;
    }

    if (status === 401) {
      // Clear session and force re-login
      sessionStorage.removeItem("username");
      sessionStorage.removeItem("password");

      if (window.location.pathname !== "/login") {
        window.location.href = "/login";
      }
    }

    return Promise.reject(error);
  }
);

export default api;

