import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import Login from "./pages/Login";
import Dashboard from "./pages/Dashboard";
import Tournaments from "./pages/Tournaments";
import TournamentDetails from "./pages/TournamentDetails"; 
import CreateTournament from "./pages/CreateTournament";
import Matches from "./pages/Matches";
import ScheduleMatch from "./pages/ScheduleMatch";
import Teams from "./pages/Teams";
import Players from "./pages/Players";
import ProtectedRoute from "./routes/ProtectedRoute";
import SubmitMatchResult from "./pages/SubmitMatchResult"; 

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Public Route */}
        <Route path="/login" element={<Login />} />

        {/* Protected Dashboard & Management */}
        <Route path="/dashboard" element={<ProtectedRoute><Dashboard /></ProtectedRoute>} />
        <Route path="/teams" element={<ProtectedRoute><Teams /></ProtectedRoute>} />
        <Route path="/players" element={<ProtectedRoute><Players /></ProtectedRoute>} />

        {/* Tournament Routes */}
        <Route path="/tournaments" element={<ProtectedRoute><Tournaments /></ProtectedRoute>} />
        <Route path="/tournaments/:id" element={<ProtectedRoute><TournamentDetails /></ProtectedRoute>} />
        <Route path="/create-tournament" element={<ProtectedRoute><CreateTournament /></ProtectedRoute>} />

        {/* Match & Scoring Routes */}
        <Route path="/matches" element={<ProtectedRoute><Matches /></ProtectedRoute>} />
        <Route path="/matches/:id/submit" element={<ProtectedRoute><SubmitMatchResult /></ProtectedRoute>} />
        <Route path="/schedule-match" element={<ProtectedRoute><ScheduleMatch /></ProtectedRoute>} />

        {/* Default Redirects */}
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;