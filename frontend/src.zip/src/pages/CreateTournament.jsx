import { useState } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

function CreateTournament() {
  const [formData, setFormData] = useState({
    name: "",
    game: "BGMI",
    format: "",
    maxTeams: "",
    startDate: ""
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e) => {
  e.preventDefault();
  setError("");
  setLoading(true);

  try {
    const tournamentData = {
      name: formData.name,
      game: formData.game, // Hardcoded to BGMI in backend for now
      format: formData.format,
      maxTeams: formData.maxTeams ? parseInt(formData.maxTeams) : null,
      startDate: formData.startDate || null,
      // Note: Backend service sets 'status' to UPCOMING and 'locked' to false automatically
    };

    await api.post("/tournaments", tournamentData);
    navigate("/tournaments");
  } catch (err) {
    setError(err.response?.data?.message || "Failed to create tournament.");
  } finally {
    setLoading(false);
  }
};

  return (
    <div>
      <Navbar />
      <div className="container">
        <div className="card" style={{ maxWidth: "600px", margin: "0 auto" }}>
          <div className="card-header">
            <h1 className="card-title">Create Tournament</h1>
          </div>

          {error && <div className="error">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Tournament Name *</label>
              <input
                type="text"
                name="name"
                className="form-input"
                placeholder="Enter tournament name"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </div>

            <div className="form-group">
              <label className="form-label">Game *</label>
              <select
                name="game"
                className="form-select"
                value={formData.game}
                onChange={handleChange}
                required
              >
                <option value="BGMI">BGMI</option>
                <option value="PUBG">PUBG</option>
                <option value="Free Fire">Free Fire</option>
                <option value="Valorant">Valorant</option>
                <option value="CS:GO">CS:GO</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Format</label>
              <input
                type="text"
                name="format"
                className="form-input"
                placeholder="e.g., Single Elimination, Round Robin"
                value={formData.format}
                onChange={handleChange}
              />
            </div>

            <div className="form-group">
              <label className="form-label">Max Teams</label>
              <input
                type="number"
                name="maxTeams"
                className="form-input"
                placeholder="Maximum number of teams"
                value={formData.maxTeams}
                onChange={handleChange}
                min="2"
              />
            </div>

            <div className="form-group">
              <label className="form-label">Start Date</label>
              <input
                type="datetime-local"
                name="startDate"
                className="form-input"
                value={formData.startDate}
                onChange={handleChange}
              />
            </div>

            <div className="flex gap-2">
              <button
                type="submit"
                className="btn btn-primary"
                disabled={loading}
              >
                {loading ? "Creating..." : "Create Tournament"}
              </button>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => navigate("/tournaments")}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default CreateTournament;
