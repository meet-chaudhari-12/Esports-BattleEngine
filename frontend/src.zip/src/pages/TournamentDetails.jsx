import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

function TournamentDetails() {
  const { id } = useParams();
  const [tournament, setTournament] = useState(null);
  const [leaderboard, setLeaderboard] = useState([]);
  const [matches, setMatches] = useState([]);
  const [loading, setLoading] = useState(true);

  // Initial data fetch
  useEffect(() => {
    fetchData();
  }, [id]);

  const fetchData = async () => {
    try {
      const [tRes, lRes, mRes] = await Promise.all([
        api.get(`/tournaments/${id}`),
        api.get(`/leaderboard/${id}`),
        api.get(`/matches/tournament/${id}`)
      ]);
      setTournament(tRes.data);
      setLeaderboard(lRes.data);
      setMatches(mRes.data);
    } catch (err) {
      console.error("Failed to load tournament details", err);
    } finally {
      setLoading(false);
    }
  };

  // Function to trigger the Universal Bracket Engine in the backend
  const handleStartTournament = async () => {
    if (!window.confirm("Are you sure? This will lock registrations and generate matches/brackets.")) return;
    
    try {
      // Calls the @PostMapping("/{id}/start") endpoint we just created
      await api.post(`/tournaments/${id}/start`);
      alert("Tournament Started! Matches generated successfully.");
      fetchData(); // Refresh to see the new matches and the 'LOCKED' status
    } catch (err) {
      alert(err.response?.data?.message || "Failed to start tournament");
    }
  };

  if (loading) return <div className="loading p-5 text-center">Loading Tournament Engine...</div>;

  return (
    <div>
      <Navbar />
      <div className="container mt-4">
        {/* Header Section with Universal Start Control */}
        <div className="header-section mb-3 flex justify-between align-center card p-2">
          <div>
            <h1 className="m-0">{tournament.name}</h1>
            <div className="mt-1">
              <span className="badge badge-primary">{tournament.game}</span>
              <span className="badge badge-info ml-1">{tournament.status}</span>
              {tournament.locked && <span className="badge badge-danger ml-1">LOCKED</span>}
            </div>
          </div>
          
          {/* Action Button: Only show Start if not locked */}
          {!tournament.locked && (
            <button 
              onClick={handleStartTournament} 
              className="btn btn-danger"
              style={{ fontWeight: 'bold' }}
            >
              Start Tournament & Generate Brackets
            </button>
          )}
        </div>

        <div className="grid grid-2 gap-2">
          {/* Section 1: Universal Leaderboard (Standings) */}
          <div className="card">
            <h3>Leaderboard / Standings</h3>
            <table className="table mt-1">
              <thead>
                <tr>
                  <th>Rank</th>
                  <th>Team</th>
                  <th>Points</th>
                  {/* Categorical column: only shows for Battle Royale logic */}
                  {(tournament.game === "BGMI" || tournament.game === "PUBG") && <th>Kills</th>}
                </tr>
              </thead>
              <tbody>
                {leaderboard.length > 0 ? (
                  leaderboard.map((entry) => (
                    <tr key={entry.teamId}>
                      <td><strong>#{entry.rank}</strong></td>
                      <td>{entry.teamName}</td>
                      <td>{entry.totalScore}</td>
                      {(tournament.game === "BGMI" || tournament.game === "PUBG") && (
                        <td>{entry.metadata?.kills || 0}</td>
                      )}
                    </tr>
                  ))
                ) : (
                  <tr>
                    <td colSpan="4" className="text-center p-2 text-light">No standings available yet.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          {/* Section 2: Match Feed (Brackets/Lobbies) */}
          <div className="card">
            <div className="flex justify-between align-center mb-1">
              <h3>Match Feed</h3>
              {/* Only allow scheduling if tournament isn't locked */}
              {!tournament.locked && (
                <Link to="/schedule-match" className="btn btn-sm btn-outline">+ Schedule Match</Link>
              )}
            </div>
            <div className="match-list" style={{ maxHeight: '500px', overflowY: 'auto' }}>
              {matches.length > 0 ? (
                matches.map((match) => (
                  <div key={match.id} className="match-item border-bottom p-1 hover-effect">
                    <div className="flex justify-between align-center">
                      <div>
                        <span className={`status-dot ${match.status === 'COMPLETED' ? 'bg-success' : 'bg-warning'}`}></span>
                        <small className="ml-1 text-light">Round {match.round || 1}</small>
                      </div>
                      <Link to={`/matches/${match.id}/submit`} className="btn-link">
                        {match.status === "COMPLETED" ? "View Results" : "Submit Score"}
                      </Link>
                    </div>
                    <div className="text-center font-bold mt-1" style={{ fontSize: '1.1rem' }}>
                      {match.teamIds && match.teamIds.length > 0 
                        ? match.teamIds.join("  VS  ") 
                        : "TBD (Waiting for previous round)"}
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center p-3 text-light">
                  No matches generated. Click <strong>"Start Tournament"</strong> to begin.
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default TournamentDetails;