import MatchList from "./MatchList";

function Matches() {
  return <MatchList />;
}

export default Matches;

