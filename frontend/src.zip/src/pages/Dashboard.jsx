import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";
import { useAuth } from "../auth/AuthContext";

function Dashboard() {
  const [stats, setStats] = useState({
    tournaments: 0,
    teams: 0,
    players: 0,
    matches: 0
  });
  const [loading, setLoading] = useState(true);
  const { user, logout } = useAuth();

  useEffect(() => {
    const fetchStats = async () => {
      try {
        const [tournaments, teams, players] = await Promise.all([
          api.get("/tournaments").catch(() => ({ data: [] })),
          api.get("/teams").catch(() => ({ data: [] })),
          api.get("/players").catch(() => ({ data: [] }))
        ]);

        setStats({
          tournaments: tournaments.data?.length || 0,
          teams: teams.data?.length || 0,
          players: players.data?.length || 0,
          matches: 0
        });
      } catch (error) {
        console.error("Error fetching stats:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchStats();
  }, []);

  const statCards = [
    { title: "Tournaments", count: stats.tournaments, link: "/tournaments", color: "var(--primary)", icon: "🏆" },
    { title: "Teams", count: stats.teams, link: "/teams", color: "var(--secondary)", icon: "👥" },
    { title: "Players", count: stats.players, link: "/players", color: "var(--success)", icon: "🎮" },
    { title: "Matches", count: stats.matches, link: "/matches", color: "var(--warning)", icon: "⚔️" }
  ];

  return (
    <div>
      <Navbar />
      <div className="container">
        <div className="card">
          <div className="card-header">
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "1rem" }}>
              <div>
                <h1 className="card-title" style={{ marginBottom: "0.25rem" }}>Dashboard</h1>
                {user?.username && (
                  <p style={{ margin: 0, fontSize: "0.9rem", color: "var(--text-light)" }}>
                    Logged in as <strong>{user.username}</strong>
                  </p>
                )}
              </div>
              <div style={{ display: "flex", gap: "0.5rem", alignItems: "center" }}>
                <button
                  type="button"
                  className="btn btn-outline"
                  onClick={logout}
                >
                  Logout
                </button>
                <Link to="/create-tournament" className="btn btn-primary">
                  + Create Tournament
                </Link>
              </div>
            </div>
          </div>

          {loading ? (
            <div className="loading">Loading statistics...</div>
          ) : (
            <div className="grid grid-2">
              {statCards.map((stat, index) => (
                <Link
                  key={index}
                  to={stat.link}
                  style={{ textDecoration: "none" }}
                >
                  <div className="card" style={{ 
                    borderLeft: `4px solid ${stat.color}`,
                    cursor: "pointer",
                    transition: "transform 0.2s"
                  }}
                  onMouseEnter={(e) => e.currentTarget.style.transform = "translateY(-4px)"}
                  onMouseLeave={(e) => e.currentTarget.style.transform = "translateY(0)"}
                  >
                    <div className="flex-between">
                      <div>
                        <h3 style={{ marginBottom: "0.5rem", color: "var(--text)" }}>
                          {stat.icon} {stat.title}
                        </h3>
                        <p style={{ fontSize: "2rem", fontWeight: "bold", color: stat.color }}>
                          {stat.count}
                        </p>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}

          <div className="card mt-3">
            <h2 className="card-title">Quick Actions</h2>
            <div className="grid grid-3" style={{ marginTop: "1rem" }}>
              <Link to="/create-tournament" className="btn btn-primary">
                Create Tournament
              </Link>
              <Link to="/teams" className="btn btn-secondary">
                Manage Teams
              </Link>
              <Link to="/players" className="btn btn-success">
                Manage Players
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
