import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

function SubmitMatchResult() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [match, setMatch] = useState(null);
  const [results, setResults] = useState({}); // Stores data for ALL teams
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMatch = async () => {
      try {
        const response = await api.get(`/matches/${id}`);
        setMatch(response.data);
        
        // Initialize state for every team in the match
        const initialResults = {};
        response.data.teamIds.forEach(teamId => {
          initialResults[teamId] = { kills: 0, placement: 0, rounds: 0, score: 0 };
        });
        setResults(initialResults);
      } catch (err) {
        console.error("Error fetching match", err);
      } finally {
        setLoading(false);
      }
    };
    fetchMatch();
  }, [id]);

  const handleInputChange = (teamId, field, value) => {
    setResults(prev => ({
      ...prev,
      [teamId]: { ...prev[teamId], [field]: parseInt(value) || 0 }
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      // Sends the universal map: { "teamId": { "kills": 5, "placement": 1 } }
      await api.post(`/matches/${id}/result`, results);
      navigate(`/tournaments/${match.tournamentId}`);
    } catch (err) {
      alert("Failed to submit result: " + (err.response?.data?.message || "Server Error"));
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div>
      <Navbar />
      <div className="container">
        <div className="card">
          <h2>Submit Result: {match.game}</h2>
          <form onSubmit={handleSubmit}>
            {match.teamIds.map(teamId => (
              <div key={teamId} className="team-row p-1 border-bottom">
                <h4>Team: {teamId}</h4>
                <div className="flex gap-2">
                  {/* DYNAMIC FIELDS BASED ON GAME TYPE */}
                  {(match.game === "BGMI" || match.game === "PUBG") ? (
                    <>
                      <input type="number" placeholder="Kills" 
                        onChange={(e) => handleInputChange(teamId, "kills", e.target.value)} />
                      <input type="number" placeholder="Placement" 
                        onChange={(e) => handleInputChange(teamId, "placement", e.target.value)} />
                    </>
                  ) : (match.game === "VALORANT") ? (
                    <input type="number" placeholder="Rounds Won" 
                      onChange={(e) => handleInputChange(teamId, "rounds", e.target.value)} />
                  ) : (
                    <input type="number" placeholder="Final Score" 
                      onChange={(e) => handleInputChange(teamId, "score", e.target.value)} />
                  )}
                </div>
              </div>
            ))}
            <button type="submit" className="btn btn-primary mt-2">Save Match Results</button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default SubmitMatchResult;