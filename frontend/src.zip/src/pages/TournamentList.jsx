import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

function TournamentList() {
  const [tournaments, setTournaments] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [refreshing, setRefreshing] = useState(false);

  useEffect(() => {
    fetchTournaments();
  }, []);

  const fetchTournaments = async () => {
    if (!loading) {
      setRefreshing(true);
    }

    try {
      const response = await api.get("/tournaments");
      setTournaments(response.data);
    } catch (err) {
      console.error(err);

      if (err.response?.status === 403) {
        setError(err.normalizedMessage || "You do not have permission to view tournaments.");
      } else if (err.response?.status === 400) {
        setError(err.normalizedMessage || "Failed to load tournaments due to a bad request.");
      } else {
        setError(err.normalizedMessage || "Failed to load tournaments.");
      }
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleLock = async (id) => {
    try {
      await api.post(`/tournaments/${id}/lock`);
      fetchTournaments();
    } catch (err) {
      console.error(err);

      if (err.response?.status === 403) {
        alert(err.normalizedMessage || "You do not have permission to lock this tournament.");
      } else if (err.response?.status === 400) {
        alert(err.normalizedMessage || "Cannot lock this tournament due to a bad request.");
      } else {
        alert(err.normalizedMessage || "Failed to lock tournament.");
      }
    }
  };

  if (loading) {
    return (
      <div>
        <Navbar />
        <div className="container">
          <div className="loading">Loading tournaments...</div>
        </div>
      </div>
    );
  }

  return (
    <div>
      <Navbar />
      <div className="container">
        <div className="card">
          <div className="card-header">
            <h1 className="card-title">Tournaments</h1>
            <Link to="/create-tournament" className="btn btn-primary">
              + Create Tournament
            </Link>
          </div>

          {error && <div className="error">{error}</div>}

          {tournaments.length === 0 ? (
            <div className="empty-state">
              <h3>No tournaments found</h3>
              <p>Create your first tournament to get started</p>
              <Link to="/create-tournament" className="btn btn-primary mt-2">
                Create Tournament
              </Link>
            </div>
          ) : (
            <div className="table-container">
              {refreshing && (
                <div className="loading" style={{ marginBottom: "0.75rem" }}>
                  Refreshing tournaments...
                </div>
              )}
              <table className="table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Game</th>
                    <th>Format</th>
                    <th>Status</th>
                    <th>Max Teams</th>
                    <th>Locked</th>
                    <th>Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {tournaments.map((tournament) => (
                    <tr key={tournament.id}>
                      <td>
                        <Link 
                          to={`/tournaments/${tournament.id}`}
                          style={{ color: "var(--primary)", fontWeight: "500" }}
                        >
                          {tournament.name}
                        </Link>
                      </td>
                      <td>{tournament.game || "N/A"}</td>
                      <td>{tournament.format || "N/A"}</td>
                      <td>
                        <span className={`badge ${
                          tournament.status === "ACTIVE" ? "badge-success" :
                          tournament.status === "COMPLETED" ? "badge-info" :
                          "badge-warning"
                        }`}>
                          {tournament.status || "PENDING"}
                        </span>
                      </td>
                      <td>{tournament.maxTeams || "N/A"}</td>
                      <td>
                        {tournament.locked ? (
                          <span className="badge badge-danger">Locked</span>
                        ) : (
                          <span className="badge badge-success">Open</span>
                        )}
                      </td>
                      <td>
                        <div className="flex gap-1">
                          <Link 
                            to={`/tournaments/${tournament.id}`}
                            className="btn btn-outline btn-sm"
                          >
                            View
                          </Link>
                          {!tournament.locked && (
                            <button
                              onClick={() => handleLock(tournament.id)}
                              className="btn btn-danger btn-sm"
                            >
                              Lock
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default TournamentList;
