import PlayerList from "./PlayerList";

function Players() {
  return <PlayerList />;
}

export default Players;

