import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import api from "../api/axios";
import { useAuth } from "../auth/AuthContext";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const navigate = useNavigate();
  const { login } = useAuth();

  const handleLogin = async (e) => {
  e.preventDefault();
  setError("");
  setLoading(true);

  try {
    // 1. Call the actual AuthController.authenticateUser endpoint
    const response = await api.post("/auth/signin", { username, password });

    // 2. Extract JwtResponse (token, username, email, roles)
    const { token, ...userData } = response.data;

    // 3. Store the JWT token for the Axios interceptor
    sessionStorage.setItem("token", token);
    sessionStorage.setItem("user", JSON.stringify(userData));

    // 4. Update AuthContext state
    login(userData.username);

    navigate("/dashboard");
  } catch (err) {
    console.error("Login error:", err);
    setError(err.response?.data?.message || "Invalid username or password.");
    sessionStorage.clear();
  } finally {
    setLoading(false);
  }
};

  return (
    <div
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: "20px"
      }}
    >
      <div className="card" style={{ maxWidth: "400px", width: "100%" }}>
        <div className="text-center mb-3">
          <h1 style={{ color: "var(--primary)", marginBottom: "0.5rem" }}>
            Esports BattleEngine
          </h1>
          <p style={{ color: "var(--text-light)" }}>Sign in to your account</p>
        </div>

        {error && <div className="error">{error}</div>}

        <form onSubmit={handleLogin}>
          <div className="form-group">
            <label className="form-label">Username</label>
            <input
              type="text"
              className="form-input"
              placeholder="Enter username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              required
            />
          </div>

          <div className="form-group">
            <label className="form-label">Password</label>
            <input
              type="password"
              className="form-input"
              placeholder="Enter password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button
            type="submit"
            className="btn btn-primary"
            style={{ width: "100%" }}
            disabled={loading}
          >
            {loading ? "Signing in..." : "Sign In"}
          </button>
        </form>

        <div className="text-center mt-2">
          <p style={{ color: "var(--text-light)" }}>
            Don't have an account?{" "}
            <Link to="/register" style={{ color: "var(--primary)" }}>
              Register here
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default Login;
