import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

function JoinTournament() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [teams, setTeams] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchTeams = async () => {
      try {
        const response = await api.get("/teams"); // Assumes you have a /teams endpoint
        setTeams(response.data);
      } catch (err) {
        console.error("Failed to fetch teams", err);
      } finally {
        setLoading(false);
      }
    };
    fetchTeams();
  }, []);

  const handleJoin = async (e) => {
    e.preventDefault();
    if (!selectedTeam) return alert("Please select a team");

    try {
      await api.post(`/tournaments/${id}/join`, { teamId: selectedTeam });
      alert("Success! Team has joined the tournament.");
      navigate(`/tournaments/${id}`);
    } catch (err) {
      alert(err.response?.data?.message || "Registration failed");
    }
  };

  if (loading) return <div className="p-5 text-center">Loading Registration Desk...</div>;

  return (
    <div>
      <Navbar />
      <div className="container mt-5">
        <div className="card shadow" style={{ maxWidth: '500px', margin: '0 auto' }}>
          <h2 className="text-center">Register for Tournament</h2>
          <p className="text-center text-light">Select your team to enter the arena</p>
          
          <form onSubmit={handleJoin} className="mt-2">
            <div className="form-group">
              <label>Select Team</label>
              <select 
                className="form-control" 
                value={selectedTeam} 
                onChange={(e) => setSelectedTeam(e.target.value)}
              >
                <option value="">-- Choose a Team --</option>
                {teams.map(team => (
                  <option key={team.id} value={team.id}>{team.name}</option>
                ))}
              </select>
            </div>
            
            <button type="submit" className="btn btn-primary btn-block mt-2">
              Confirm Registration
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default JoinTournament;