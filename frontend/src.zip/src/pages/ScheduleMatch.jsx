import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import api from "../api/axios";
import Navbar from "../components/Navbar";

function ScheduleMatch() {
  const [tournaments, setTournaments] = useState([]);
  const [teams, setTeams] = useState([]);
  const [formData, setFormData] = useState({
    tournamentId: "",
    teamIds: [],
    scheduledAt: ""
  });
  const [selectedTeam, setSelectedTeam] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const navigate = useNavigate();

  useEffect(() => {
    fetchTournaments();
    fetchTeams();
  }, []);

  const fetchTournaments = async () => {
    try {
      const response = await api.get("/tournaments");
      setTournaments(response.data);
    } catch (err) {
      console.error(err);
      setError(
        err.normalizedMessage ||
          "Failed to load tournaments. You may not have permission or the server may be down."
      );
    }
  };

  const fetchTeams = async () => {
    try {
      const response = await api.get("/teams");
      setTeams(response.data);
    } catch (err) {
      console.error(err);
      setError(
        err.normalizedMessage ||
          "Failed to load teams. You may not have permission or the server may be down."
      );
    }
  };

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const addTeam = () => {
    if (selectedTeam && !formData.teamIds.includes(selectedTeam)) {
      setFormData({
        ...formData,
        teamIds: [...formData.teamIds, selectedTeam]
      });
      setSelectedTeam("");
    }
  };

  const removeTeam = (teamId) => {
    setFormData({
      ...formData,
      teamIds: formData.teamIds.filter(id => id !== teamId)
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");

    if (formData.teamIds.length < 2) {
      setError("Please select at least 2 teams");
      return;
    }

    setLoading(true);

    try {
      const matchData = {
        tournamentId: formData.tournamentId,
        teamIds: formData.teamIds,
        scheduledAt: formData.scheduledAt || null,
        status: "SCHEDULED"
      };

      await api.post("/matches/schedule", matchData);
      navigate("/matches");
    } catch (err) {
      console.error(err);

      if (err.response?.status === 400) {
        setError(
          err.normalizedMessage ||
            "Invalid match data or tournament is locked. Please check your input and try again."
        );
      } else if (err.response?.status === 403) {
        setError(
          err.normalizedMessage ||
            "You do not have permission to schedule matches for this tournament."
        );
      } else {
        setError(
          err.normalizedMessage ||
            "Failed to schedule match. Please try again."
        );
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <Navbar />
      <div className="container">
        <div className="card" style={{ maxWidth: "600px", margin: "0 auto" }}>
          <div className="card-header">
            <h1 className="card-title">Schedule Match</h1>
          </div>

          {error && <div className="error">{error}</div>}

          <form onSubmit={handleSubmit}>
            <div className="form-group">
              <label className="form-label">Tournament *</label>
              <select
                name="tournamentId"
                className="form-select"
                value={formData.tournamentId}
                onChange={handleChange}
                required
              >
                <option value="">Select tournament</option>
                {tournaments.map((tournament) => (
                  <option key={tournament.id} value={tournament.id}>
                    {tournament.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Add Teams *</label>
              <div className="flex gap-1">
                <select
                  className="form-select"
                  value={selectedTeam}
                  onChange={(e) => setSelectedTeam(e.target.value)}
                >
                  <option value="">Select team</option>
                  {teams.map((team) => (
                    <option key={team.id} value={team.id}>
                      {team.name}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  className="btn btn-secondary"
                  onClick={addTeam}
                >
                  Add
                </button>
              </div>
              {formData.teamIds.length > 0 && (
                <div style={{ marginTop: "1rem" }}>
                  <p style={{ marginBottom: "0.5rem", fontWeight: "500" }}>Selected Teams:</p>
                  <div className="flex gap-1" style={{ flexWrap: "wrap" }}>
                    {formData.teamIds.map((teamId) => {
                      const team = teams.find(t => t.id === teamId);
                      return (
                        <span
                          key={teamId}
                          className="badge badge-info"
                          style={{ cursor: "pointer" }}
                          onClick={() => removeTeam(teamId)}
                        >
                          {team?.name || teamId} ×
                        </span>
                      );
                    })}
                  </div>
                </div>
              )}
            </div>

            <div className="form-group">
              <label className="form-label">Scheduled Date & Time</label>
              <input
                type="datetime-local"
                name="scheduledAt"
                className="form-input"
                value={formData.scheduledAt}
                onChange={handleChange}
              />
            </div>

            <div className="flex gap-2">
              <button
                type="submit"
                className="btn btn-primary"
                disabled={loading}
              >
                {loading ? "Scheduling..." : "Schedule Match"}
              </button>
              <button
                type="button"
                className="btn btn-outline"
                onClick={() => navigate("/matches")}
              >
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}

export default ScheduleMatch;
