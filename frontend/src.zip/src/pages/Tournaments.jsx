import React, { useEffect, useState } from 'react';
import api from '../api/axios';

const Tournaments = () => {
    const [tournaments, setTournaments] = useState([]);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // In a real scenario, we fetch.
        // For now, if fetch fails, we show mock data so UI looks good.
        api.get('/tournaments')
            .then(res => setTournaments(res.data))
            .catch(err => {
                console.error("Failed to fetch tournaments", err);
                // Fallback Mock Data
                setTournaments([
                    { id: '1', name: 'Winter Championship 2026', status: 'LIVE', teams: 8 },
                    { id: '2', name: 'Valorant Community Cup', status: 'REGISTRATION', teams: 16 },
                    { id: '3', name: 'Midnight League', status: 'COMPLETED', teams: 4 },
                ]);
            })
            .finally(() => setLoading(false));
    }, []);

    if (loading) return <div className="container" style={{ paddingTop: '4rem' }}>Loading...</div>;

    return (
        <div className="container page-tournaments">
            <h1 className="page-title">Active Tournaments</h1>

            <div className="tournament-grid">
                {tournaments.map(t => (
                    <div key={t.id} className="glass-panel tournament-card">
                        <div className={`status-badge ${t.status?.toLowerCase()}`}>{t.status || 'UNKNOWN'}</div>
                        <h3 className="card-title">{t.name}</h3>
                        <div className="card-meta">
                            <span>{t.teams || 0} Teams</span>
                            <span>•</span>
                            <span>5v5</span>
                        </div>
                        <button className="btn-primary" style={{ marginTop: '1rem', width: '100%' }}>View Bracket</button>
                    </div>
                ))}
            </div>

            <style>{`
        .page-tournaments {
          padding-top: 2rem;
        }
        .page-title {
          font-size: 2rem;
          margin-bottom: 2rem;
        }
        .tournament-grid {
          display: grid;
          grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
          gap: 2rem;
        }
        .tournament-card {
          padding: 1.5rem;
          transition: transform 0.2s;
        }
        .tournament-card:hover {
          transform: translateY(-5px);
        }
        .status-badge {
          display: inline-block;
          font-size: 0.75rem;
          font-weight: 700;
          padding: 0.25rem 0.5rem;
          border-radius: 4px;
          margin-bottom: 1rem;
        }
        .status-badge.live { background: rgba(255, 0, 85, 0.2); color: var(--accent-hot); border: 1px solid var(--accent-hot); }
        .status-badge.registration { background: rgba(0, 255, 157, 0.2); color: var(--accent-primary); border: 1px solid var(--accent-primary); }
        .status-badge.completed { background: rgba(255, 255, 255, 0.1); color: var(--text-secondary); }
        
        .card-title {
          font-size: 1.25rem;
          margin-bottom: 0.5rem;
        }
        .card-meta {
          color: var(--text-secondary);
          display: flex;
          gap: 0.5rem;
          font-size: 0.9rem;
        }
      `}</style>
        </div>
    );
};

export default Tournaments;
