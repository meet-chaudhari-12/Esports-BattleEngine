import TeamList from "./TeamList";

function Teams() {
  return <TeamList />;
}

export default Teams;

