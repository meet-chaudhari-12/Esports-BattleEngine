import React from 'react';

const Home = () => {
    return (
        <div className="page-home">
            <section className="hero container">
                <h1 className="hero-title">
                    Forge Your <br />
                    <span className="text-gradient">Esports Legacy</span>
                </h1>
                <p className="hero-subtitle">
                    The ultimate platform for tournament management and advanced player analytics.
                    Dominate the leaderboard today.
                </p>

                <div className="hero-actions">
                    <button className="btn-primary">Explore Tournaments</button>
                    <button className="btn-secondary">View Analytics</button>
                </div>
            </section>

            <style>{`
        .page-home {
          min-height: 80vh;
          display: flex;
          align-items: center;
          justify-content: center;
          text-align: center;
          padding-top: 4rem;
        }
        .hero-title {
          font-size: 4rem;
          line-height: 1.1;
          margin-bottom: 1.5rem;
          font-weight: 800;
        }
        .hero-subtitle {
          font-size: 1.25rem;
          color: var(--text-secondary);
          margin-bottom: 2.5rem;
          max-width: 600px;
          margin-left: auto;
          margin-right: auto;
        }
        .hero-actions {
          display: flex;
          gap: 1rem;
          justify-content: center;
        }
        .btn-secondary {
          background: rgba(255,255,255,0.05);
          color: var(--text-primary);
          padding: 0.75rem 1.5rem;
          border-radius: 8px;
          border: 1px solid var(--border-subtle);
          transition: background 0.2s;
        }
        .btn-secondary:hover {
          background: rgba(255,255,255,0.1);
        }
      `}</style>
        </div>
    );
};

export default Home;
