import { createContext, useContext, useEffect, useState } from "react";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  // Initialize from sessionStorage on first load/refresh
  useEffect(() => {
    const username = sessionStorage.getItem("username");
    if (username) {
      setUser({ username });
    }
  }, []);

  const login = (username) => {
    setUser({ username });
  };

  const logout = () => {
    sessionStorage.removeItem("username");
    sessionStorage.removeItem("password");
    setUser(null);
  };

  const value = {
    user,
    isAuthenticated: !!user,
    login,
    logout
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return ctx;
}

