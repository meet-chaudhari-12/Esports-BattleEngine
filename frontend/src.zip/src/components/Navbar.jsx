import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../auth/AuthContext";

function Navbar() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  return (
    <nav className="navbar">
      <div className="navbar-content">
        <Link to="/dashboard" className="navbar-brand">
          🎮 Esports BattleEngine
        </Link>
        <div className="navbar-links">
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/tournaments">Tournaments</Link>
          <Link to="/teams">Teams</Link>
          <Link to="/players">Players</Link>
          <Link to="/matches">Matches</Link>
          <Link to="/leaderboard">Leaderboard</Link>
          {user && (
            <span style={{ marginRight: "0.5rem", fontSize: "0.9rem" }}>
              {user.username}
            </span>
          )}
          <button 
            onClick={handleLogout}
            className="btn btn-outline btn-sm"
          >
            Logout
          </button>
        </div>
      </div>
    </nav>
  );
}

export default Navbar;
